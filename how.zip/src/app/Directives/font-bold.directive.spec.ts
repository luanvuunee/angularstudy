import { FontBoldDirective } from './font-bold.directive';

describe('FontBoldDirective', () => {
  it('should create an instance', () => {
    const directive = new FontBoldDirective();
    expect(directive).toBeTruthy();
  });
});
